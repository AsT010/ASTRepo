

@interface UIView (Origin)

@property (nonatomic) CGPoint origin;

@property (nonatomic) CGFloat xOrigin;
@property (nonatomic) CGFloat yOrigin;

@property (nonatomic) CGFloat xCenter;
@property (nonatomic) CGFloat yCenter;

@end