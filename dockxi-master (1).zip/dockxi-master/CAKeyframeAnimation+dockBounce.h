

@interface CAKeyframeAnimation (DockBounce)

+ (CAKeyframeAnimation *)dockBounceAnimationWithIconHeight:(CGFloat)iconHeight;

@end
