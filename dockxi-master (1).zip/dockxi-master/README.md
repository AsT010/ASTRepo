# DockXI

# Credits for original code goes to <a href="https://github.com/eswick">eswick</a> and modifications were done by <a href="https://github.com/jakeajames">Jakeajames</a>

# All I did was make it so people can compile this tweak for testing on Simulator using Simject, some parts may have been broken in the process, so feel free to fix things as you wish.
