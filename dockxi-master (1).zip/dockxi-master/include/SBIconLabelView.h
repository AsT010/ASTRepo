


@interface SBIconLabelView : UIView



@end
